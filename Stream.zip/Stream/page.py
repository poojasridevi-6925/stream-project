#To create a simple slide bar web page
import streamlit as st
import pandas as pd

st.sidebar.title("Pages")
st.set_page_config(page_title="page",layout='centered')
page=st.sidebar.radio("Go to",["home","about","contact","support"])

if page=="home":
    st.snow()
    st.title("Home page")
    st.subheader("This is the home page")
    st.markdown("""Homepage is for all the Details""")
elif page=="about":
    st.title("This is about")
    st.text("this is about page we created")
elif page=="contact":
    with st.form("contact"):
        st.title("Contact Page")
        name=st.text_input("enter user name")
        email=st.text_input("enter email")
        st.text_area("please send a message")
        submit=st.form_submit_button("send")
        if submit:
            st.success(f"thank you {name}")
elif page=='support':
    st.title("support page")
    st.markdown("email:page@gmail.com")

   # TO RUN the cmd is streamlit run page.py