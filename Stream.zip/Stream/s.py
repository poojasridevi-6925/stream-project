# import streamlit as st #(we get the loading page,balloons,buttons ,etc... .This is the code)
# import time 
# with st.spinner("Loading...."):
#     time.sleep(3)
# progress=st.progress(50)
# for i in range(100):
#     time.sleep(0.01)
#     progress.progress(i+1)
# st.title("HELLO WORLD")
# st.header("hello")
# st.subheader('hello')
# st.text("VIBHU")
# st.markdown("**Srivi**")
# st.code("Good Morning Hyderabad")

# import streamlit as st
# import pandas as pd
# st.button("click")
# st.balloons()
# st.snow()


# # This is for showing the graphs.
# import streamlit as st
# import pandas as pd
# df=pd.DataFrame({
#     "name":["a","b","c","d"], #add comma at last
#     "score":[57,67,55,445]
# })
# st.dataframe(df)
# st.table(df.head(1)) #in table the top column we get
# st.table(df.tail(2)) #last 2
# st.line_chart(df)
# st.area_chart(df)
# st.bar_chart(df)


# import streamlit as st
# import pandas as pd
# if st.button('click here'):
#    st.error('oops try again!')
# if st.button('done'):
#     st.success("button created successfully") #**for clicking the button the we get button created....**



# import streamlit as st
# import pandas as pd
# st.download_button("down","HI! This is Srivibhavana Godishela,Pursuing B.Tech in MRECW",file_name='a.txt') #this is for creating a file and downloading.
# import streamlit as st
# import pandas as pd
# st.camera_input('selfie please') #this is for web camera



# #for uploading the files
# import streamlit as st
# import pandas as pd
# st.file_uploader("file") 



# import streamlit as st
# import pandas as pd
# st.metric("growth","$100",+5) #for increment & decrement.


# #to show the address in the map with latitude and longitude}
# import streamlit as st
# import pandas as pd
# data=pd.DataFrame({
#     'longitude':[79.5127],
#     'latitude':[18.7263]
# })
# st.map(data=data,zoom=12)




# #to enter name and age the to give successfull.
# import streamlit as st
# import pandas as pd
# a=st.text_input("enter ur name")
# st.number_input('enter ur age',min_value=0,max_value=75)
# if st.button("done"):
#     st.success(f"thank you {a}")



# import streamlit as st
# import pandas as pd
# st.checkbox('helloooo')
# if st.radio("Gender",['Female','Male']):
#     if st.button("done"):
#         st.success("login successfull")
# st.multiselect("select",[1,2,3,4])



# from streamlit_lottie import st_lottie
# import requests
# def home(url):
#     r=requests.get(url)
#     if r.status_code!=200:
#         return None
#     return r.json()
# s=home("https://assets9.lottiefiles.com/packages/lf20_usmfx6bp.json")
# st_lottie(s,height=300)

# #streamlit run s.py