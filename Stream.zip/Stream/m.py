import pandas as pd #to allow dataframes
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import streamlit as st
df=pd.read_csv("house_prices.csv")
print(df)

X=df.drop(['Price'],axis=True)
y=df['Price']

X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.1)
model=LinearRegression()
model.fit(X_train,y_train)

import joblib
joblib.dump(model,"price.pkl")
model=joblib.load("price.pkl")

area=st.number_input("enter the sqrt",min_value=100,max_value=1000)
bedroom=st.number_input("enter no.of bedrooms",min_value=1,max_value=5)
bathroom=st.number_input("enter bathroom",min_value=2,max_value=5)
if st.button("submit"):
    prediction=model.predict([[area,bedroom,bathroom]])
    st.success(f"the house price---{prediction[0]:.2f}")

#to run -- python m.py